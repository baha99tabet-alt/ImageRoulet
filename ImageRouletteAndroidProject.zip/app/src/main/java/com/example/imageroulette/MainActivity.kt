package com.example.imageroulette

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private val images = mutableListOf<Uri>()
    private var current = 0
    private var spinning = false
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var imageView: ImageView
    private lateinit var status: TextView
    private lateinit var spinButton: Button

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            images.clear()
            images.addAll(uris)
            current = 0
            imageView.setImageURI(images[0])
            status.text = "تم تحميل ${images.size} صورة"
            spinButton.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)
        status = findViewById(R.id.status)
        spinButton = findViewById(R.id.spinButton)

        findViewById<Button>(R.id.selectButton).setOnClickListener {
            picker.launch(arrayOf("image/*"))
        }

        spinButton.setOnClickListener { spin() }
    }

    private fun spin() {
        if (spinning || images.isEmpty()) return
        spinning = true
        spinButton.isEnabled = false

        val target = Random.nextInt(images.size)
        val rounds = 2 * images.size
        val total = rounds + target
        var step = 0
        var delay = 25L

        fun tick() {
            current = (current + 1) % images.size
            imageView.setImageURI(images[current])

            if (step++ < total) {
                if (step > total - 25) delay += 8
                handler.postDelayed({ tick() }, delay)
            } else {
                current = target
                imageView.setImageURI(images[current])
                status.text = "🎉 تم اختيار الصورة رقم ${current + 1} من ${images.size}"
                spinning = false
                spinButton.isEnabled = true
            }
        }
        tick()
    }
}
